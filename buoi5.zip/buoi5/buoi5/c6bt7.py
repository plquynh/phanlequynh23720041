# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 20:13:42 2024

@author: Phan Le Quynh 23720041 
"""

print("========== MENU ==========")
print("1.Hu tieu")
print("2.Chao Long")
print("3.Banh canh")
print("4.Bun rieu")
print("5.Pho bo")
print("===========================")
print(" Moi nhap lua chon: ")
print("===========================")


