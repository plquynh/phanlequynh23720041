# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 18:14:19 2024

@author: Phan Le Quynh 23720041
"""

a = float(input("Nhap a:"))
b = float(input("Nhap b:"))
c = float(input("Nhap c:"))
d = float(input("Nhap d:"))
tbc = (a+b+c+d)/4
print("trung binh cong 4 so la:",tbc)
      