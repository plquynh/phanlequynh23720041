# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 19:44:07 2024

@author: Phan Le Quynh 23720041 
"""
gio = int(input("Nhap gio:"))
phut = int(input("Nhap phut:"))
giay = int(input("Nhap giay:"))
tong_giay = gio * 3600 + phut * 60 + giay
print("Doi ra giay la:",tong_giay)