# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 19:06:19 2024

@author: Phan Le Quynh 23720041 
"""

a = float(input("Nhap a:"))
b = float(input("Nhap b:"))
tong = a+b
hieu = a-b
tich = a*b
thuong = a/b
chialaydu = a % b
chialaynguyen = a // b
print("tong 2 so la:",tong)
print("hieu 2 so la:",hieu)
print("tich 2 so la:",tich)
print("thuong 2 so la:",thuong)
print("chia lay du 2 so la:",chialaydu)
print("chia lay nguyen 2 so la:",chialaynguyen)