# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 20:05:22 2024

@author: Phan Le Quynh 23720041
"""
a = float(input("nhap vao he so a:"))
b = float(input("nhap vao he so b:"))
c = float(input("nhap vao he so c:"))
if a !=0:
    print("phuong trinh bac 2 ax2+bx+c")
else:
    print("khong phai phuong trinh bac 2")